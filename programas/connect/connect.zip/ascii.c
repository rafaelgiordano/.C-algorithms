#include <stdio.h>

int main ()
{
	int ascii;
	for (ascii = 0; ascii <= 500; ascii++)
	{
	printf ("%d - %c\n", ascii, ascii);
	}
	return 0;
}